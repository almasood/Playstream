# PlayStream Android starter

A first Android Studio starter for a free live-TV + movies + series app, with a phone-friendly Compose UI and a catalogue layout that can be adapted for Android TV.

## Included
- Home screen with Live TV, Movies, and Series rails
- Search/filter
- Selectable content cards
- Dark streaming-style design
- Placeholder catalogue only; no copyrighted streams are bundled

## Open it
1. Install Android Studio on a computer.
2. Extract this folder.
3. In Android Studio choose **Open** and select the `playstream_android` folder.
4. Allow Gradle sync, then run on an Android phone or emulator.

## Important next steps
- Replace demo titles with content you own or have permission to distribute.
- Add a backend/API for the catalogue and channel metadata.
- Integrate AndroidX Media3 ExoPlayer for HLS/DASH playback from authorized URLs.
- For a production Android TV build, add TV-specific navigation/focus handling and test with a remote.
- Add parental controls, privacy policy, crash reporting, and accessibility checks before release.

This is source code for a starter project, not a ready-to-install APK. It has not been built or tested in Android Studio in this environment.


## Playback added in v0.2
- Integrated AndroidX Media3 ExoPlayer.
- Selecting a demo card lets you paste a direct HTTP(S) stream URL and launch the player.
- Playback supports formats supported by the installed Media3 modules; HLS is supported through ExoPlayer's HLS support where configured. For explicit HLS module support, add `androidx.media3:media3-exoplayer-hls:1.5.1` to `app/build.gradle.kts`.
- No live-TV channel URLs are preloaded because stream rights and availability must be verified per provider.
- Only use URLs you have permission to access and redistribute. A publicly accessible link is not automatically licensed for redistribution.
