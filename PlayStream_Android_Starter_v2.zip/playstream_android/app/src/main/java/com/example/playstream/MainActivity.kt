package com.example.playstream

import android.os.Bundle
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF090B12)
private val Panel = Color(0xFF171B27)
private val Violet = Color(0xFF9B6CFF)
private val Muted = Color(0xFF9DA4B8)

data class MediaItem(
    val title: String,
    val type: String,
    val genre: String,
    val description: String,
    val tag: String
)

private val liveChannels = listOf(
    MediaItem("News Live", "LIVE TV", "News", "A placeholder channel card. Add a licensed live stream URL to enable playback.", "LIVE"),
    MediaItem("Sports Arena", "LIVE TV", "Sports", "A placeholder channel card. Add a licensed live stream URL to enable playback.", "SPORTS"),
    MediaItem("World View", "LIVE TV", "Documentary", "A placeholder channel card. Add a licensed live stream URL to enable playback.", "WORLD"),
    MediaItem("Music Mix", "LIVE TV", "Music", "A placeholder channel card. Add a licensed live stream URL to enable playback.", "MUSIC")
)
private val movies = listOf(
    MediaItem("Midnight Run", "MOVIE", "Action", "Demo title for your catalogue. Replace with licensed metadata and artwork.", "ACTION"),
    MediaItem("Blue Horizon", "MOVIE", "Drama", "Demo title for your catalogue. Replace with licensed metadata and artwork.", "DRAMA"),
    MediaItem("Laugh Out", "MOVIE", "Comedy", "Demo title for your catalogue. Replace with licensed metadata and artwork.", "COMEDY"),
    MediaItem("Wild Planet", "MOVIE", "Nature", "Demo title for your catalogue. Replace with licensed metadata and artwork.", "NATURE")
)
private val series = listOf(
    MediaItem("City Stories", "SERIES", "Drama", "A demo series card for the first prototype.", "S1 • 8 EP"),
    MediaItem("The Last Signal", "SERIES", "Sci-Fi", "A demo series card for the first prototype.", "S1 • 6 EP"),
    MediaItem("Kitchen Kings", "SERIES", "Reality", "A demo series card for the first prototype.", "S2 • 10 EP")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PlayStreamApp() }
    }
}

@Composable
fun PlayStreamApp() {
    val context = LocalContext.current
    var tab by remember { mutableStateOf("Home") }
    var selected by remember { mutableStateOf<MediaItem?>(null) }
    var search by remember { mutableStateOf("") }
    var streamUrl by remember { mutableStateOf("") }
    var urlError by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Ink,
            surface = Panel,
            primary = Violet,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Box(Modifier.fillMaxSize().background(Ink)) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(38.dp).background(Violet, RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("▶", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("PLAYSTREAM", fontSize = 18.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                            Text("Entertainment for everyone", fontSize = 10.sp, color = Muted)
                        }
                    }
                    Text("FREE", color = Color(0xFF6DE2B5), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                    placeholder = { Text("Search channels, movies, series…", color = Muted) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Violet,
                        unfocusedBorderColor = Color(0xFF303647),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = Violet
                    )
                )

                Spacer(Modifier.height(18.dp))
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Home", "Live TV", "Movies", "Series").forEach { label ->
                        FilterChip(
                            selected = tab == label,
                            onClick = { tab = label },
                            label = { Text(label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Violet,
                                selectedLabelColor = Color.White,
                                labelColor = Muted
                            )
                        )
                    }
                }

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(bottom = 28.dp)
                ) {
                    if (tab == "Home") {
                        item {
                            HeroBanner(onClick = { selected = movies.first(); streamUrl = ""; urlError = false })
                        }
                    }
                    if (tab == "Home" || tab == "Live TV") {
                        item { SectionHeader("Live TV", "Watch now") }
                        item { MediaRail(liveChannels.filterMatches(search), onSelect = { selected = it; streamUrl = ""; urlError = false }) }
                    }
                    if (tab == "Home" || tab == "Movies") {
                        item { SectionHeader("Movies", "Explore films") }
                        item { MediaRail(movies.filterMatches(search), onSelect = { selected = it; streamUrl = ""; urlError = false }) }
                    }
                    if (tab == "Home" || tab == "Series") {
                        item { SectionHeader("Series", "Binge your favourites") }
                        item { MediaRail(series.filterMatches(search), onSelect = { selected = it; streamUrl = ""; urlError = false }) }
                    }
                    item {
                        Text(
                            "Free to use • Demo catalogue • Add licensed streams before launch",
                            color = Muted, fontSize = 11.sp,
                            modifier = Modifier.fillMaxWidth().padding(20.dp)
                        )
                    }
                }
            }

            selected?.let { item ->
                AlertDialog(
                    onDismissRequest = { selected = null; urlError = false },
                    title = { Text(item.title, fontWeight = FontWeight.Bold) },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("${item.type}  •  ${item.genre}", color = Violet, fontSize = 12.sp)
                            Text(item.description)
                            Text("Paste a direct stream URL you are allowed to watch or distribute. HLS (.m3u8) and supported video URLs work best.", color = Muted, fontSize = 12.sp)
                            OutlinedTextField(
                                value = streamUrl,
                                onValueChange = { streamUrl = it; urlError = false },
                                label = { Text("Stream URL") },
                                placeholder = { Text("https://…/playlist.m3u8") },
                                singleLine = true,
                                isError = urlError,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Violet,
                                    unfocusedBorderColor = Color(0xFF41465A),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    cursorColor = Violet
                                )
                            )
                            if (urlError) Text("Enter a valid http:// or https:// URL.", color = Color(0xFFFF8585), fontSize = 12.sp)
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val url = streamUrl.trim()
                            if (url.startsWith("https://") || url.startsWith("http://")) {
                                context.startActivity(Intent(context, PlayerActivity::class.java).putExtra(PlayerActivity.EXTRA_URL, url))
                                selected = null
                                urlError = false
                            } else {
                                urlError = true
                            }
                        }) { Text("Play") }
                    },
                    dismissButton = {
                        TextButton(onClick = { selected = null; urlError = false }) { Text("Cancel") }
                    },
                    containerColor = Panel,
                    titleContentColor = Color.White,
                    textContentColor = Color.White
                )
            }
        }
    }
}

private fun List<MediaItem>.filterMatches(query: String): List<MediaItem> =
    if (query.isBlank()) this else filter {
        it.title.contains(query, ignoreCase = true) ||
        it.genre.contains(query, ignoreCase = true) ||
        it.type.contains(query, ignoreCase = true)
    }

@Composable
private fun HeroBanner(onClick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp)
            .background(
                Brush.linearGradient(listOf(Color(0xFF34245F), Color(0xFF171B27), Color(0xFF252B42))),
                RoundedCornerShape(22.dp)
            )
            .clickable(onClick = onClick)
            .padding(22.dp)
    ) {
        Text("YOUR NEXT FAVOURITE", color = Color(0xFFBDA4FF), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
        Spacer(Modifier.height(10.dp))
        Text("Stories worth
staying in for.", fontSize = 30.sp, lineHeight = 34.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(10.dp))
        Text("Movies • Series • Live TV", color = Color(0xFFD0D3E0), fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("▶  Explore featured title", fontWeight = FontWeight.Bold, color = Color.White,
                modifier = Modifier.background(Violet, RoundedCornerShape(12.dp)).padding(horizontal = 15.dp, vertical = 10.dp))
        }
    }
}

@Composable
private fun SectionHeader(title: String, subtitle: String) {
    Row(
        Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 10.dp),
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun MediaRail(items: List<MediaItem>, onSelect: (MediaItem) -> Unit) {
    if (items.isEmpty()) {
        Text("No matches found.", color = Muted, modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp))
        return
    }
    LazyRow(
        contentPadding = PaddingValues(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(items) { item ->
            Column(
                Modifier.width(148.dp).clickable { onSelect(item) },
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    Modifier.fillMaxWidth().height(112.dp)
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    when (item.genre) {
                                        "Sports" -> Color(0xFF126E62)
                                        "News" -> Color(0xFF3458A5)
                                        "Comedy" -> Color(0xFF9C5C2D)
                                        "Sci-Fi" -> Color(0xFF493A91)
                                        "Nature" -> Color(0xFF39724E)
                                        else -> Color(0xFF343B58)
                                    },
                                    Color(0xFF171B27)
                                )
                            ),
                            RoundedCornerShape(16.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text("▶", fontSize = 28.sp, color = Color.White)
                    Text(
                        item.tag,
                        modifier = Modifier.align(Alignment.BottomStart).padding(9.dp)
                            .background(Color(0xB8000000), RoundedCornerShape(6.dp)).padding(horizontal = 7.dp, vertical = 4.dp),
                        fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White
                    )
                }
                Text(item.title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(item.genre, fontSize = 11.sp, color = Muted)
            }
        }
    }
}
